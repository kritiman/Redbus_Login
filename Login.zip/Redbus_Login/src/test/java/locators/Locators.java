package locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import browser.Browser;

public class Locators extends Browser {

	public static WebElement icon() {
		WebElement icon = driver.findElement(By.xpath("//*[@id=\"i-icon-profile\"]"));
		return icon;
	}


	public static WebElement signin() {
		WebElement signin = driver.findElement(By.xpath("//li[@id='signInLink']"));
		return signin;
	}
	
	
	public static WebElement gmail() {
		WebElement gmail = driver.findElement(By.xpath("//*[@id='identifierId']"));	
		return gmail;
	}
	
	public static WebElement gmail_next() {
		WebElement gmail_next = driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/div/button/span"));
		return gmail_next;
	}

}