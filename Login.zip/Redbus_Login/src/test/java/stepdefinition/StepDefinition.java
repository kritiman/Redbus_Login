package stepdefinition;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebElement;

import browser.Browser;
import excel.Read;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import locators.Locators;

public class StepDefinition extends Browser {
	
	@Given("User is on signup\\/signin window")
	public void user_is_on_signup_signin_window() {
		try {
		Browser.setChromeDriver();
		Browser.getUrl();
		Locators.icon().click();
		Locators.signin().click();
		Thread.sleep(5000);
		
		System.out.println("User is on signin window");
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		}catch(Exception e) {
			System.out.println(e);
		}
	}

	@When("User enters registered Gmail id")
	public void user_enters_registered_Gmail_id() {
		try {
		String mainWindowHandle = driver.getWindowHandle();
		   Set<String> allWindowHandles = driver.getWindowHandles();
	       Iterator<String> iterator = allWindowHandles.iterator();
	     System.out.println("Outside While Loop");
	      while (iterator.hasNext()) 
	     {
	        	String ChildWindow = iterator.next();
	        		if (!mainWindowHandle.equalsIgnoreCase(ChildWindow)) 
	               {
	             driver.switchTo().window(ChildWindow);
	               System.out.println("Title :"+driver.getTitle());
	               try {
	           		//Invoking method to get the test data value from Excel file
	           			String gmailid = Read.readExcel(0, 0);
	           			WebElement input1 = Locators.gmail();
	           			input1.sendKeys(gmailid);
	           			
	           			Locators.gmail_next().click();
	           			
	               }catch(Exception e)
	           		{
	           			System.out.println("Gmail way is not working");
	           		}
	           	
	    //throw new io.cucumber.java.PendingException();
	               
	           	}}
		}catch(Exception e) {
			System.out.println(e);
		}
	}

	@Then("User is redirected to homepage")
	public void user_is_redirected_to_homepage() {
		try {
		System.out.println("user navigated to home page of redbus");
	    // Write code here that turns the phrase above into concrete actions
	   // throw new io.cucumber.java.PendingException();
	}catch(Exception e) {
	System.out.println(e);	
	}
	}
}
	
